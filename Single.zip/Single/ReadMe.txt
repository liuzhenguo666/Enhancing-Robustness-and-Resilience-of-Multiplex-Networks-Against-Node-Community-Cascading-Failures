Single文件夹下的ER网络、SF网络和SW网络均为单层网络
这些单层网络可作为合成多重网络的素材，如合成ER-SF-SW网络

ER单层网络的生成程序是主文件夹下的"Save_SingleERNetwork"，该程序中可根据需要设置参数并在“ER”文件夹中创建对应的文件夹存储自定义生成的单层ER网络，现有的ER文件夹中的单层ER网络以及文件夹名称，均是修改“Save_SingleERNetwork”中的 path 存储路径得到的。

SW单层网络的生成程序是主文件夹下的"Save_SingleSWNetwork"，该程序中可根据需要设置参数并在“SW”文件夹中创建对应的文件夹存储自定义生成的单层SW网络，现有的SW文件夹中的单层SW网络以及文件夹名称，均是修改“Save_SingleSWNetwork”中的 path 存储路径得到的。
















