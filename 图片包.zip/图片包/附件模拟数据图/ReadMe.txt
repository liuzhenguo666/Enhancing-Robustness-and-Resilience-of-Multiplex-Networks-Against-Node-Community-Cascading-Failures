
文件'k4community_qc..'和'k6community_qc..'系列分别为对应的 kA=kB=4 与 kA=kB=6下的ER-ER网络使用计算机模拟生成的模拟数据，用以验证理论值，具体数值可从figure中提取。文件命名包含了相关参数信息，例如'k4community_qc07'表示 kA=kB=4,qc=0.7下的ER-ER 网络模拟结果。

当社区功能节点数低于 qc 比例后，社区失效，qc值越大,社区越脆弱，与附件参数 lambda 的关系是 qc = 1 - lambda
当社区失效节点数超过 lambda 比例后，社区失效，lambda值越小，社区越脆弱

如果想用理论值和模拟值比对，在主文件夹中的“Main_PercolationTheoryFormulation.m”设置好参数后，打开对应参数的 'k4community_qc..'或'k6community_qc..'的figure文件，然后点击运行，理论值图像会叠绘在此文件夹中的figure上







































