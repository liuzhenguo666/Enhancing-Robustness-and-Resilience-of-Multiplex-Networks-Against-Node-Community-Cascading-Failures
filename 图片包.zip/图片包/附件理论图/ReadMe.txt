
此文件夹下的figure图是使用主文件夹下“Main_PercolationTheoryFormulation.m”与文件夹“图片包/附件模拟数据图”中的文件'k4community_qc..'和'k6community_qc..'叠绘而成。例如文件'theory_k6community_qc05'就是文件'k6community_qc05'和对应参数下两个理论值曲线的叠绘结果图
















